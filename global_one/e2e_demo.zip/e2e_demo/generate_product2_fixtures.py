"""
Generates 5-row JSONL test data for Product2 -- the table that's now the
SOLE bu/did source (per Dakota: "Product2 should not have a null or blank
did/bu... it's okay to remove the invoice line resolution" — InvoiceLine's
own Business_Unit_BU__c/Department_ID_DID__c are no longer read at all).

PROD01AAA is deliberately given a DIFFERENT did than its InvoiceLine
(IL0001AAA has did=20500; Product2 PROD01AAA has did=20999) specifically
to prove Product2's value actually shows up in the output, not just that
it's present.

PROD05AAA (the "trap" InvoiceLine's product, IL0005AAA) is included WITH
its old bu/did=99999/99999 -- this matters for real: since InvoiceLine's
own bu/did fields are no longer read at all, IL0005AAA's
Business_Unit_BU__c=99999 is now completely inert and can never surface
through the pipeline regardless of whether line-level-vs-header-level
priority logic is correct. Without a matching Product2 record here, the
trap scenario's "99999 must never appear" check would pass trivially even
if that priority logic broke -- PROD05AAA needs a REAL 99999/99999
Product2 record so the trap is still live: if priority ever regresses and
resolves the wrong Product2Id, a real, detectable 99999 shows up in the
output again, same as it did before this whole Product2 rewrite.

Run with: python3 generate_product2_fixtures.py
Writes to table_fixtures/product2.jsonl.
"""

import json
import os

OUT_DIR = os.path.join(os.path.dirname(__file__), "table_fixtures")


def _write(table_name: str, rows: list):
    path = os.path.join(OUT_DIR, f"{table_name}.jsonl")
    with open(path, "w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")
    return path


def _product_row(**overrides):
    row = {
        "Id": None, "Name": None, "ProductCode": None, "Description": None,
        "IsActive": True,
        "CreatedDate": "2026-01-01T00:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-01-01T00:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-01-01T00:00:00.000+0000",
        "Family": None, "IsDeleted": False, "IsArchived": False,
        "Type": None, "Business_Unit_BU__c": None, "Department_ID_DID__c": None,
    }
    row.update(overrides)
    return row


PRODUCT2 = [
    # PROD01AAA -- deliberately DIFFERENT did than InvoiceLine IL0001AAA
    # (20500) to prove Product2 actually wins, not just that it's present.
    _product_row(Id="01tKa00000PROD01AAA", Name="Acme Widget Plan", ProductCode="WIDGET-01",
                 Business_Unit_BU__c="10902", Department_ID_DID__c="20999"),
    _product_row(Id="01tKa00000PROD02AAA", Name="Support Retainer", ProductCode="SUPPORT-01",
                 Business_Unit_BU__c="10902", Department_ID_DID__c="20500"),
    _product_row(Id="01tKa00000PROD03AAA", Name="Professional Services", ProductCode="PS-01",
                 Business_Unit_BU__c="10904", Department_ID_DID__c="50500"),
    _product_row(Id="01tKa00000PROD04AAA", Name="Refund Adjustment Product", ProductCode="REFUND-ADJ",
                 Business_Unit_BU__c="10905", Department_ID_DID__c="60500"),
    # PROD05AAA -- the "trap" InvoiceLine's (IL0005AAA) product. Given a
    # REAL 99999/99999 record here (not omitted) -- see this file's
    # docstring for why this matters now that InvoiceLine's own bu/did
    # fields are no longer read at all: without this, the "99999 must
    # never appear" trap check would pass trivially even if the
    # line-level-vs-header-level priority logic broke.
    _product_row(Id="01tKa00000PROD05AAA", Name="HeaderLevel Plan B (should never win)", ProductCode="TRAP-01",
                 Business_Unit_BU__c="99999", Department_ID_DID__c="99999"),
    _product_row(Id="01tKa00000PROD06AAA", Name="Unrelated product", ProductCode="OTHER-01",
                 Business_Unit_BU__c="10901", Department_ID_DID__c="30500"),
]


def generate_all():
    return [_write("product2", PRODUCT2)]


if __name__ == "__main__":
    for path in generate_all():
        with open(path) as f:
            n = sum(1 for _ in f)
        print(f"wrote {path} ({n} rows)")
