"""
A local-filesystem-backed fake S3 client implementing exactly the two
calls helpers/s3_utils.py makes:
  - s3_client.get_paginator("list_objects_v2").paginate(Bucket=, Prefix=)
  - s3_client.get_object(Bucket=, Key=)

This lets the end-to-end demo run the REAL read_jsonl_prefix_from_s3() /
read_table_by_dataset_id() code, not a bypassed/mocked version — the only
thing faked is the S3 transport itself, backed by files on disk instead of
an actual bucket.
"""

import io
import os


class _FakeBody:
    def __init__(self, data: bytes):
        self._data = data

    def read(self):
        return self._data


class _FakePaginator:
    def __init__(self, root_dir: str):
        self.root_dir = root_dir

    def paginate(self, Bucket, Prefix):  # noqa: N803 (matches boto3's real param casing)
        prefix_path = os.path.join(self.root_dir, Prefix)
        contents = []
        if os.path.isdir(prefix_path):
            for name in sorted(os.listdir(prefix_path)):
                full_path = os.path.join(prefix_path, name)
                if os.path.isfile(full_path):
                    key = os.path.join(Prefix, name)
                    contents.append({"Key": key})
        # Single page is enough for this demo's data volume.
        yield {"Contents": contents}


class FakeS3Client:
    """
    root_dir plays the role of the bucket root — every Key is resolved as
    a path relative to root_dir, exactly mirroring how the real bucket's
    keys map to salesforce/reports/{dataset_id}/... prefixes.
    """

    def __init__(self, root_dir: str):
        self.root_dir = root_dir

    def get_paginator(self, operation_name):
        assert operation_name == "list_objects_v2"
        return _FakePaginator(self.root_dir)

    def get_object(self, Bucket, Key):  # noqa: N803
        full_path = os.path.join(self.root_dir, Key)
        with open(full_path, "rb") as f:
            data = f.read()
        return {"Body": _FakeBody(data)}
