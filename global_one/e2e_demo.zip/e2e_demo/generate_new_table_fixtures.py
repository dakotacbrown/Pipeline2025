"""
Generates 5-row JSONL test data for the 4 tables added to
gl_source_join.py's TransactionType resolution (in what's now called
resolve_product2_id(), renamed from resolve_bu_did()): DebitMemoLine,
Payment, Refund, RefundLinePayment.

Field names/types for DebitMemoLine and RefundLinePayment specifically are
lower-confidence than the rest of this project's fixtures — only the
fields Dakota explicitly confirmed (Id, ReferenceRecordId for
DebitMemoLine; Id, RefundId, PaymentId for RefundLinePayment) are certain.
The remaining audit/standard fields follow the same pattern every other
Salesforce object in this project uses (Id, IsDeleted, Name, CreatedDate,
etc.) but weren't individually screenshot-confirmed for these two objects
specifically — worth a spot-check against the real DDL before relying on
this beyond local testing.

Payment/Refund fixtures reuse Payment.Id values that already exist in
table_fixtures/payment_line_invoice.jsonl (PAY002AAA/PAY003AAA/PAY004AAA/
PAY005AAA), so the new RefundLinePayment rows resolve through REAL,
working header-level chains when run against the existing InvoiceLine
fixture data — not just structurally-valid-but-untested JSON.

Run with: python3 generate_new_table_fixtures.py
Writes to table_fixtures/{table_name}.jsonl (same directory
generate_table_fixtures.py uses).
"""

import json
import os

OUT_DIR = os.path.join(os.path.dirname(__file__), "table_fixtures")


def _write(table_name: str, rows: list):
    path = os.path.join(OUT_DIR, f"{table_name}.jsonl")
    with open(path, "w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")
    return path


# ---------------------------------------------------------------------------
# debit_memo_line — confirmed fields: Id, ReferenceRecordId (-> InvoiceLine.Id)
# ---------------------------------------------------------------------------

def _dml_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-10T09:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-10T09:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-10T09:00:00.000+0000",
        "LastViewedDate": None, "LastReferencedDate": None,
        "DebitMemoId": None, "ReferenceRecordId": None,
        "StartDate": "2026-08-01", "EndDate": "2026-08-31",
        "ChargeAmount": None, "Description": None,
        "LegalEntityId": "0fwKa0000001xaRIAQ", "LegalEntityAccountingPeriodId": None,
    }
    row.update(overrides)
    return row


DEBIT_MEMO_LINE = [
    # Points at existing InvoiceLine fixtures (see table_fixtures/invoice_line.jsonl)
    # so these resolve against real data when run through the pipeline.
    _dml_row(Id="a0KKa00000DML001AAA", Name="00000001-1", DebitMemoId="a0LKa00000DBM001AAA",
             ReferenceRecordId="a0BKa00000IL0001AAA", ChargeAmount=120.00,
             Description="Debit memo against Acme Widget Plan"),
    _dml_row(Id="a0KKa00000DML002AAA", Name="00000002-1", DebitMemoId="a0LKa00000DBM002AAA",
             ReferenceRecordId="a0BKa00000IL0002AAA", ChargeAmount=45.00,
             Description="Debit memo against Support Retainer"),
    _dml_row(Id="a0KKa00000DML003AAA", Name="00000003-1", DebitMemoId="a0LKa00000DBM003AAA",
             ReferenceRecordId="a0BKa00000IL0003AAA", ChargeAmount=15.00),
    _dml_row(Id="a0KKa00000DML004AAA", Name="00000004-1", DebitMemoId="a0LKa00000DBM004AAA",
             ReferenceRecordId="a0BKa00000IL0004AAA", ChargeAmount=8.00),
    # Deliberately unmatched -- no InvoiceLine with this Id exists in the
    # fixture data, so this row should resolve to null bu/did (-> the
    # "10901" default), same as any other unresolvable row.
    _dml_row(Id="a0KKa00000DML005AAA", Name="00000005-1", DebitMemoId="a0LKa00000DBM005AAA",
             ReferenceRecordId="a0BKa00000IL_NOMATCH", ChargeAmount=2.00),
]


# ---------------------------------------------------------------------------
# payment — only "Id" is actually used (the new Refund/RefundLinePayment
# join hop, per Dakota: "keep payment just to make sure there's nothing
# lost in the joins"). Reuses PaymentIds already referenced by
# payment_line_invoice.jsonl so the join hop actually matches real rows.
# ---------------------------------------------------------------------------

def _payment_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-07T11:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-07T11:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-07T11:00:00.000+0000",
        "Status": "Processed", "Type": "Electronic", "Amount": None,
    }
    row.update(overrides)
    return row


PAYMENT = [
    # PAY002-PAY005 already appear as PaymentLineInvoice.PaymentId in
    # table_fixtures/payment_line_invoice.jsonl -- reused here (not new
    # IDs) so the RefundLinePayment->Payment->PaymentLineInvoice chain
    # below resolves through a real, matching Payment.Id.
    _payment_row(Id="a0FKa00000PAY002AAA", Name="PMT-00002", Amount=100.00),
    _payment_row(Id="a0FKa00000PAY003AAA", Name="PMT-00003", Amount=50.00),
    _payment_row(Id="a0FKa00000PAY004AAA", Name="PMT-00004", Amount=25.00),
    _payment_row(Id="a0FKa00000PAY005AAA", Name="PMT-00005", Amount=1.00),
    # A Payment with no PaymentLineInvoice / RefundLinePayment pointing at
    # it at all -- included for completeness, not exercised by any join.
    _payment_row(Id="a0FKa00000PAY006AAA", Name="PMT-00006", Amount=500.00),
]


# ---------------------------------------------------------------------------
# refund — only "Id" is actually used, as the entry point for the "Refund"
# TransactionType (one hop earlier than RefundLinePayment, via RefundId).
# ---------------------------------------------------------------------------

def _refund_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-11T10:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-11T10:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-11T10:00:00.000+0000",
        "Status": "Processed", "Type": "Electronic", "Amount": None,
    }
    row.update(overrides)
    return row


REFUND = [
    _refund_row(Id="a0MKa00000REF001AAA", Name="REF-00001", Amount=100.00),
    _refund_row(Id="a0MKa00000REF002AAA", Name="REF-00002", Amount=50.00),
    _refund_row(Id="a0MKa00000REF003AAA", Name="REF-00003", Amount=25.00),
    # Deliberately has no matching RefundLinePayment row below -- should
    # resolve to null bu/did.
    _refund_row(Id="a0MKa00000REF004AAA", Name="REF-00004", Amount=10.00),
    _refund_row(Id="a0MKa00000REF005AAA", Name="REF-00005", Amount=1.00),
]


# ---------------------------------------------------------------------------
# refund_line_payment — confirmed fields: Id, RefundId, PaymentId.
# NOTE: this table's real dataset_id registration hasn't gone through yet
# (per Dakota) -- these rows are for LOCAL TESTING ONLY, to prove the
# resolution logic is correct and ready, not a preview of real prod data.
# ---------------------------------------------------------------------------

def _rlp_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-11T10:15:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-11T10:15:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-11T10:15:00.000+0000",
        "RefundId": None, "PaymentId": None,
        "Amount": None, "Type": "Refund",
    }
    row.update(overrides)
    return row


REFUND_LINE_PAYMENT = [
    # RLP1: reached via BOTH entry points -- directly (TransactionType =
    # RefundLinePayment, using this row's own Id) AND indirectly via
    # Refund REF001 (TransactionType = Refund, one hop earlier). Both
    # should resolve to the SAME InvoiceLine (via PAY002 -> INV001 -> IL001,
    # bu=10902/did=20500), proving the two entry points share one
    # downstream chain correctly.
    _rlp_row(Id="a0NKa00000RLP001AAA", Name="RLP-00001", RefundId="a0MKa00000REF001AAA",
             PaymentId="a0FKa00000PAY002AAA", Amount=100.00),
    _rlp_row(Id="a0NKa00000RLP002AAA", Name="RLP-00002", RefundId="a0MKa00000REF002AAA",
             PaymentId="a0FKa00000PAY003AAA", Amount=50.00),
    # A second RefundLinePayment under the SAME Refund as RLP001 above --
    # per resolve_product2_id()'s drop_duplicates(keep="first"), only the FIRST
    # match for REF001 (RLP001, via PAY002) wins when resolving through the
    # "Refund" TransactionType entry point; this row is only reachable
    # directly, via its own Id, under "RefundLinePayment".
    _rlp_row(Id="a0NKa00000RLP003AAA", Name="RLP-00003", RefundId="a0MKa00000REF001AAA",
             PaymentId="a0FKa00000PAY004AAA", Amount=25.00),
    # Points at a Payment (PAY006) with no PaymentLineInvoice/
    # PaymentLineInvoiceLine row at all -- should resolve to null bu/did
    # even though the RefundLinePayment -> Payment hop itself succeeds.
    _rlp_row(Id="a0NKa00000RLP004AAA", Name="RLP-00004", RefundId="a0MKa00000REF003AAA",
             PaymentId="a0FKa00000PAY006AAA", Amount=5.00),
    # Points at a PaymentId that doesn't exist in payment.jsonl at all --
    # documents that the Payment join is non-filtering (per Dakota): this
    # row still resolves normally via PaymentLineInvoice using the
    # original PaymentId, the missing Payment match doesn't block it.
    _rlp_row(Id="a0NKa00000RLP005AAA", Name="RLP-00005", RefundId="a0MKa00000REF005AAA",
             PaymentId="a0FKa00000PAY005AAA", Amount=1.00),
]


def generate_all():
    written = []
    written.append(_write("debit_memo_line", DEBIT_MEMO_LINE))
    written.append(_write("payment", PAYMENT))
    written.append(_write("refund", REFUND))
    written.append(_write("refund_line_payment", REFUND_LINE_PAYMENT))
    return written


if __name__ == "__main__":
    for path in generate_all():
        with open(path) as f:
            n = sum(1 for _ in f)
        print(f"wrote {path} ({n} rows)")
