"""
End-to-end demo: generates realistic fixture data, runs the REAL
gl_source_join.build_source_dataframe() -> salesforce_global_one.build_gl_file()
pipeline against it (through a fake-but-real-code-path S3 client, not
mocked-out internals), and writes out everything you'd want to eyeball:

  output/01_joined_dataframe.csv   - what build_source_dataframe() produced
  output/02_gl_journal_file.txt    - the actual fixed-width file
  output/03_decoded_breakdown.txt  - the fixed-width file, decoded back into
                                      labeled fields per DECODE_METADATA, so
                                      you can check field alignment by eye
  output/04_run_log.txt            - every log.info() message from the run

Run with: python3 run_e2e_test.py
(from inside the repo root, or anywhere — paths are relative to this file)

See SCENARIOS_README.md for what each of the 11 test transactions proves
and what to expect in the output.
"""

import logging
import os
import sys
from datetime import datetime

DEMO_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(DEMO_DIR)
SCRIPTS_DIR = os.path.join(REPO_ROOT, "src", "salesforce", "resources", "scripts")
STUBS_DIR = os.path.join(REPO_ROOT, "stubs")

# Same sys.path setup as conftest.py — stubs first (for pyspark /
# asvc1scoredataservices_common, which helper_functions.py imports at
# module load time), then repo root (src.-qualified imports), then the
# scripts dir itself (bare "helpers..." imports, the form the scripts use
# internally — see gl_source_join.py's own module docstring on why).
sys.path.insert(0, STUBS_DIR)
sys.path.insert(0, REPO_ROOT)
sys.path.insert(0, SCRIPTS_DIR)

sys.path.insert(0, DEMO_DIR)  # for generate_fixtures / fake_s3_client, local to this demo

import generate_fixtures  # noqa: E402
from fake_s3_client import FakeS3Client  # noqa: E402

import helpers.gl_source_join as gl_source_join  # noqa: E402
import salesforce_global_one as gljb  # noqa: E402

OUTPUT_DIR = os.path.join(DEMO_DIR, "output")


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # ---- 1. Generate fixture data --------------------------------------
    print("Generating fixture data...")
    written = generate_fixtures.generate_all()
    for path in written:
        print(f"  wrote {path}")
    print()

    # ---- 2. Set up logging (captured to both stdout and a file) --------
    log = logging.getLogger("e2e_demo")
    log.setLevel(logging.INFO)
    log.handlers.clear()
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(logging.Formatter("%(message)s"))
    log.addHandler(stream_handler)

    log_file_path = os.path.join(OUTPUT_DIR, "04_run_log.txt")
    file_handler = logging.FileHandler(log_file_path, mode="w")
    file_handler.setFormatter(logging.Formatter("%(message)s"))
    log.addHandler(file_handler)

    # ---- 3. Run the REAL pipeline against the fixture data -------------
    fake_s3 = FakeS3Client(root_dir=os.path.join(DEMO_DIR, "test_data"))

    print("=" * 78)
    print("Running gl_source_join.build_source_dataframe()...")
    print("=" * 78)
    df = gl_source_join.build_source_dataframe(
        fake_s3,
        bucket="fake-bucket",  # unused by FakeS3Client, kept for API parity
        source_prefix=generate_fixtures.SOURCE_PREFIX,
        log=log,
        # Aug 1 - Aug 20, 2026: covers scenarios 1-11's dates (Aug 5-14),
        # excludes scenario 8 (dated July 15) on purpose.
        start_date="2026-08-01",
        end_date="2026-08-20",
    )
    print()
    print(f"build_source_dataframe() returned {len(df)} rows "
          f"(11 scenarios in, scenario 8 filtered out by date -> expect 10).")
    print()

    csv_path = os.path.join(OUTPUT_DIR, "01_joined_dataframe.csv")
    df.to_csv(csv_path, index=False)
    print(f"Wrote joined dataframe to {csv_path}")
    print()
    print(df.to_string())
    print()

    # ---- 4. Run the REAL file-building step -----------------------------
    print("=" * 78)
    print("Running salesforce_global_one.build_gl_file()...")
    print("=" * 78)
    # Fixed creation_dt so the output is reproducible run-to-run.
    creation_dt = datetime(2026, 8, 20, 9, 0, 0)
    content = gljb.build_gl_file(df, business_unit=None, source="CS1", creation_dt=creation_dt)

    txt_path = os.path.join(OUTPUT_DIR, "02_gl_journal_file.txt")
    with open(txt_path, "w") as f:
        f.write(content)
    print(f"Wrote GL journal file to {txt_path}")
    print()
    print(content)

    # ---- 5. Decode the fixed-width file back into labeled fields --------
    breakdown_path = os.path.join(OUTPUT_DIR, "03_decoded_breakdown.txt")
    breakdown = decode_file(content)
    with open(breakdown_path, "w") as f:
        f.write(breakdown)
    print(f"Wrote decoded field breakdown to {breakdown_path}")
    print()
    print(breakdown)


def decode_file(content: str) -> str:
    """
    Decodes the fixed-width file back into labeled fields per
    DECODE_METADATA, so you can visually confirm each field lines up with
    what build_gl_file() actually wrote — same metadata OneStream itself
    uses to decode the file.
    """
    by_name = {d["recordName"]: d for d in gljb.DECODE_METADATA["multiRecordDefinitions"]}

    def record_name_for_line(line: str) -> str:
        if line.startswith("#H"):
            return "file_header"
        if line.startswith("H"):
            return "journal_header"
        if line.startswith("L"):
            return "journal_line_detail"
        if line.startswith("#T"):
            return "file_trailer"
        return None

    lines_out = []
    for line_num, line in enumerate(content.split("\n"), start=1):
        if not line:
            continue
        record_name = record_name_for_line(line)
        if record_name is None:
            lines_out.append(f"Line {line_num}: UNRECOGNIZED: {line!r}")
            continue
        record_def = by_name[record_name]
        lines_out.append(f"Line {line_num} [{record_name}] (len={len(line)}):")
        for field_def in record_def["fieldDefinitions"]:
            # DECODE_METADATA positions are 0-indexed (confirmed: the
            # top-level record_type_1 field is explicitly at position 0,
            # the very first character) — NOT 1-indexed. No -1 offset.
            start = field_def["position"]
            width = field_def["width"]
            value = line[start:start + width]
            lines_out.append(f"    {field_def['fieldName']:<32} = {value!r}")
        lines_out.append("")

    return "\n".join(lines_out)


if __name__ == "__main__":
    main()
