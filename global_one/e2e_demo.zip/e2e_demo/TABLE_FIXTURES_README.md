# Standalone per-table test data

`table_fixtures/*.jsonl` — 5 rows per table, one flat file per table,
using every column from the actual DDL spreadsheets (not just the
trimmed subset `gl_source_join.py`'s `EXPECTED_COLUMNS` reads). This is
meant to be more robust/realistic than the minimal fixtures in
`generate_fixtures.py` — closer to a real S3-landed JSONL dump.

## Scope

Started as the 9 tables `build_source_dataframe()` originally loaded, and
has grown alongside the pipeline itself — now covers every table the
Product2-only architecture actually reads, split across four generator
scripts (all run automatically by `run_table_fixtures_test.py`):

```
generate_table_fixtures.py       transaction_journal, invoice_line,
                                  invoice_line_tax, payment_line_invoice_line,
                                  payment_line_invoice, credit_memo_line,
                                  credit_memo_line_invoice_line,
                                  credit_memo_inv_application,
                                  general_ledger_account
generate_new_table_fixtures.py   debit_memo_line, payment, refund,
                                  refund_line_payment
generate_product2_fixtures.py    product2
```

**`Payment`, `Refund`, and `Product2` ARE now included** — an earlier
version of this note said they weren't, back when `build_source_dataframe()`
didn't load them yet. Product2 in particular is now the SOLE bu/did
source, universally (see `salesforce_general_ledger_schema.md`) — nothing
in this pipeline works correctly without it anymore.

Not yet covered: `credit_memo_line_tax`, `debit_memo_line_tax` (the two
newest tables, added for `CreditMemoLineTax`/`DebitMemoLineTax`'s own
standalone `TransactionType`s) — say so if you want fixtures for those too.

**Field names/types are transcribed from the DDL screenshots across our
conversation** — worth a spot-check against the real spreadsheets before
relying on this beyond local testing. The fields that actually matter to
the pipeline (join keys, `Business_Unit_BU__c`/`Department_ID_DID__c`,
`GL_Accounting_Number__c`, `ActivityDate`, `TransactionType`,
`Credit`/`Debit`, `Debit`/`CreditGeneralLedgerAccountId`) I'm confident
in; a few of the unused-by-the-pipeline filler fields were reconstructed
from memory and are lower-confidence.

## How the 5 rows are designed

The rows aren't random — they're cross-linked by ID so that running them
through the real pipeline exercises every resolution path in one pass:

| TransactionJournal row | Type | Proves |
|---|---|---|
| S1 | InvoiceLine | Direct resolution |
| S2 | InvoiceLineTax | One-hop indirect resolution (→ InvoiceLine) |
| S3 | Payment | Line-level (`PaymentLineInvoiceLine`) wins over header-level (`PaymentLineInvoice`) — a "trap" row exists that only the header-level path would reach |
| S4 | CreditMemo | Same line-level-wins-over-header-level proof, via `CreditMemoLine`/`CreditMemoLineInvoiceLine` vs. `CreditMemoInvApplication` |
| S5 | InvoiceLine | `GeneralLedgerAccount` GL_Accounting_Number__c `"10040049"` → `did` overrides to `"16605"` |

Each supporting table also carries a few additional filler rows (valid,
just not referenced by any TransactionJournal row) — this exercises that
the pipeline correctly *ignores* irrelevant rows too, not just correctly
resolves relevant ones.

## Running it

```
python3 generate_table_fixtures.py   # writes table_fixtures/*.jsonl
python3 run_table_fixtures_test.py   # stages them + runs the real pipeline
```

`run_table_fixtures_test.py` prints the joined dataframe, the full
fixed-width output, and a full set of sanity checks — current state:

```
S1 (IL1, Product2 overrides did 20500->20999): 20999 present: True
S12 DebitMemoLine -> bu=10902 present:        True
S13 RefundLinePayment direct -> bu=10902:     True
S14 Refund via RefundLinePayment hop -> 10902: True
IL3 (line-level Payment target)   bu=10904 present: True
IL4 (line-level CreditMemo target) bu=10905 present: True
IL5 (trap, should NEVER appear)    bu=99999 present: False
S5's did override to 16605 present: True
```

## Two real bugs this run caught

1. **My own fixture bug**: S5's `TransactionJournal.ReferenceTransactionRecordId`
   accidentally pointed at the same ID as the trap `InvoiceLine` (both
   were `IL5`), so S5 resolved to the trap's wrong `bu`/`did` (`99999`)
   instead of a real one. Fixed by pointing S5 at `IL1` instead — S5 is
   testing the GL-account override, not a new bu/did resolution path, so
   reusing an existing valid InvoiceLine is fine.
2. **A real pipeline bug in `fmt()`** (`salesforce_global_one.py`): the
   null check was `isinstance(value, float) and pd.isna(value)`, which
   only catches `float('nan')`. Now that `read_jsonl_from_s3()` reads
   every column as pandas' nullable `StringDtype`, a missing value is
   `pd.NA` — not a `float` — so the old check silently missed it. Before
   the fix, any legitimately-null field (e.g. `UsageType` on a
   Payment/CreditMemo transaction, which realistically has none) wrote
   the literal text `"<NA>"` into the fixed-width output instead of blank
   spaces. **Fixed** by using `pd.isna(value)` alone, which correctly
   catches `None`, `NaN`, `pd.NA`, and `pd.NaT` in one check. Regression
   tests: `test_pandas_na_becomes_blank_field`,
   `test_nat_becomes_blank_field` in `test_gl_journal_builder.py`.

Neither bug was visible in `generate_fixtures.py`'s original 11-scenario
demo, because those fixtures happened to always supply a real string (or
`None` via direct `pd.DataFrame` construction) for every optional field —
they never round-tripped genuinely-missing fields through the real
`read_jsonl_from_s3()` → `StringDtype` path the way these full-schema
fixtures do.

## `debit_memo_line.jsonl` / `payment.jsonl` / `refund.jsonl` / `refund_line_payment.jsonl`

Added for the three new TransactionType resolution paths (DebitMemoLine,
RefundLinePayment, Refund). Generate with `generate_new_table_fixtures.py`
(runs automatically as part of `run_table_fixtures_test.py`).

**Confidence note:** only the fields Dakota explicitly confirmed are
certain — `Id`/`ReferenceRecordId` for DebitMemoLine, `Id`/`RefundId`/
`PaymentId` for RefundLinePayment. The remaining audit fields
(`CreatedDate`, `IsDeleted`, etc.) follow this project's usual pattern but
weren't individually screenshot-confirmed for these two objects — worth a
spot-check against the real DDL before relying on this beyond local
testing.

**`payment.jsonl` and `refund.jsonl` intentionally reuse PaymentIds**
already present in `payment_line_invoice.jsonl` (PAY002–PAY005), so the
new RefundLinePayment rows resolve through a real, working header-level
chain when run against the existing InvoiceLine fixtures — not just
well-formed-but-untested JSON.

**Important caveat:** `refund_line_payment`'s real dataset_id registration
hasn't gone through yet. `run_table_fixtures_test.py` stages this fixture
under the current PLACEHOLDER dataset_id
(`00000000-0000-0000-0000-000000000000`) purely to prove the resolution
*code* is correct — this does not mean real production data is available.
Production reads of `refund_line_payment` will return 0 rows, and Refund/
RefundLinePayment TransactionType rows will fall to the `"10901"` bu
default with a null department_id, until that registration completes.

Three new scenarios were added to `generate_table_fixtures.py`'s
`TRANSACTION_JOURNAL` list to exercise these paths end to end:

| # | `TransactionJournal.Name` | Type | Proves |
|---|---|---|---|
| S12 | DebitMemoLine direct | `DebitMemoLine` | Single-hop resolution via `ReferenceRecordId` -> InvoiceLine, resolves to `10902`/`20500` |
| S13 | RefundLinePayment direct entry | `RefundLinePayment` | `RefundLinePayment.Id` directly -> Payment -> PaymentLineInvoice -> InvoiceLine, resolves to `10902`/`20500` |
| S14 | Refund via RefundLinePayment hop | `Refund` | One hop earlier (`Refund.Id` -> `RefundLinePayment.RefundId`) -> same downstream chain, also resolves to `10902`/`20500` -- same InvoiceLine as S13's underlying `RefundLinePayment` row, confirming both entry points share one correct chain |

Run `python3 run_table_fixtures_test.py` to see all three resolve
correctly, alongside the existing line-level-wins and `10040049`-override
checks.

## `product2.jsonl`

Added when Product2 became the sole bu/did source (see
`salesforce_general_ledger_schema.md` for the full architecture note).
Generated by `generate_product2_fixtures.py`.

`PROD01AAA` is deliberately given a different `did` (`20999`) than its
`InvoiceLine` (`20500`) — proves Product2's value actually shows up in
the output, not just that it's present (S1's check above).

**`PROD05AAA` — the "trap" InvoiceLine's product — is included WITH a
real `99999`/`99999` record, not omitted.** This matters for a subtle
reason worth knowing: since `InvoiceLine`'s own `Business_Unit_BU__c` is
no longer read at all now that Product2 is the sole source, `IL0005AAA`'s
`Business_Unit_BU__c=99999` became completely inert the moment Product2
took over — it can never surface through the pipeline regardless of
whether the line-level-vs-header-level priority logic (S3/S4's whole
purpose) is actually still correct. Without a matching Product2 record
here, the "`99999` must never appear" check would have started passing
*trivially* — not because the priority logic still works, but because
`99999` had no path to the output at all anymore, silently neutering the
test. Giving `PROD05AAA` a real `99999`/`99999` Product2 record restores
the trap: if priority logic ever regresses and resolves the wrong
`Product2Id`, a real, detectable `99999` shows up in the output again,
same as it always did.

## Three more real bugs this project's fixtures have caught

Beyond the two in the section above (`fmt()`'s `pd.NA` check, and the S5
fixture ID collision), building and running these fixtures against the
real pipeline caught three more real issues, none of which a unit test
alone had surfaced:

1. **`Payment`'s own resolution was gated on a matching row in the
   `Payment` table** — a regression introduced during the Product2
   rewrite. `TransactionType="Payment"`'s `ReferenceTransactionRecordId`
   already IS the `PaymentId` directly; it never needed to be confirmed
   against a separately-loaded `Payment` table (that confirmation hop was
   only ever meant for `RefundLinePayment`/`Refund`, per Dakota: "keep
   payment just to make sure there's nothing lost in the joins"). Caught
   because `payment.jsonl` (from `generate_new_table_fixtures.py`)
   doesn't include every `PaymentId` referenced elsewhere — S3's real
   fixture data exposed the gap immediately; a hand-crafted unit test
   fixture had happened to include a matching row and missed it. Fixed;
   regression test added.
2. **`CreditMemo`'s "line-level via `CreditMemoLineInvoiceLine`"
   candidate was structurally dead code** — it derived from the same
   `CreditMemoLine` table, keyed by the same `CreditMemoId`, as the
   direct candidate, which is always tried first; since the dedup keeps
   the first candidate regardless of whether its value is null, the
   junction-table path could never actually change the result. Found
   while writing a test for it, not by running these fixtures — but
   confirms the same lesson: real, cross-linked data (or in this case,
   deliberately constructing the exact scenario where two candidates
   would disagree) surfaces things isolated unit tests can miss. Removed.
3. **The `IL5` trap's `99999` marker went silently inert** — documented
   in the `product2.jsonl` section above. Caught by re-reading what the
   trap scenario was actually supposed to prove after the Product2
   rewrite, not by a failing test (nothing failed — that was the
   problem).
