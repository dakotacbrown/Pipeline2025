"""
Generates standalone, full-schema JSONL test data — 5 rows per table,
every column from the actual DDL spreadsheets (not just the trimmed
subset gl_source_join.py's EXPECTED_COLUMNS reads) — for the 9 tables
build_source_dataframe() actually loads:

    transaction_journal, invoice_line, invoice_line_tax,
    payment_line_invoice_line, payment_line_invoice, credit_memo_line,
    credit_memo_line_invoice_line, credit_memo_inv_application,
    general_ledger_account

Payment/CreditMemo/Invoice/Account/Refund/Product2 aren't included here —
build_source_dataframe() never loads those tables directly (their header-
level joins go through PaymentLineInvoice/CreditMemoInvApplication
directly to InvoiceLine, without needing the Payment/CreditMemo/Invoice
header objects themselves), so full fixtures for them wouldn't add
anything toward testing the GL file specifically.

Field names/types are transcribed from the DDL spreadsheet screenshots
across this conversation — worth a spot-check against the real sheets
before relying on this for anything beyond local testing, since a few
minor (unused-by-the-pipeline) fields were reconstructed from memory
rather than re-confirmed.

The 5 rows per table are coherently cross-linked (not independent random
rows) to exercise every resolution path in one pass when run through the
real pipeline:

  TJ1 (InvoiceLine)   -> direct resolution, via IL1
  TJ2 (InvoiceLineTax)-> one-hop indirect resolution, via ILT1 -> IL2
  TJ3 (Payment)       -> line-level (PaymentLineInvoiceLine -> IL3) should
                         win over header-level (PaymentLineInvoice -> a
                         deliberately-wrong "trap" InvoiceLine, IL5)
  TJ4 (CreditMemo)    -> line-level (CreditMemoLine -> CreditMemoLineInvoiceLine
                         -> IL4) should win over header-level
                         (CreditMemoInvApplication -> the same trap, IL5)
  TJ5 (InvoiceLine)   -> GeneralLedgerAccount "10040049" override -> did
                         should resolve to "16605"

Each supporting table also gets a few additional filler rows (still valid,
just not referenced by any TJ row) purely to reach 5 rows and to prove the
pipeline correctly ignores irrelevant data, not just correctly resolves
relevant data.

Run with: python3 generate_table_fixtures.py
Writes one flat file per table to ./table_fixtures/{table_name}.jsonl
"""

import json
import os

OUT_DIR = os.path.join(os.path.dirname(__file__), "table_fixtures")


def _write(table_name: str, rows: list):
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, f"{table_name}.jsonl")
    with open(path, "w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")
    return path


# ---------------------------------------------------------------------------
# transaction_journal — full TransactionJournal schema
# ---------------------------------------------------------------------------

def _tj_row(**overrides):
    row = {
        "Id": None, "Name": None, "IsDeleted": False,
        "CreatedById": "005Ka000005SyJYIA0", "CreatedDate": "2026-08-01T12:00:00.000+0000",
        "LastModifiedDate": "2026-08-01T12:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-01T12:00:00.000+0000",
        "AccountId": None,  # confirmed NOT populated in practice
        "ActivityDate": None, "Status": "Processed",
        "ExternalTransactionNumber": None, "UsageType": None,
        "StartDate": None, "EndDate": None,
        "TransactionAmount": None, "Quantity": None, "QuantityUnitOfMeasureId": None,
        "UsageResourceId": None, "TransactionType": None,
        "LegalEntityId": "0fwKa0000001xaRIAQ",
        "DebitGeneralLedgerAccountId": None, "CreditGeneralLedgerAccountId": None,
        "ReferenceTransactionRecordId": None,
        "GeneralLedgerAcctAsgntRuleId": None, "UniqueIdentifier": None,
        "LegalEntyAccountingPeriodId": None,
        "Credit": None, "Debit": None,
        "UsageSummaryId": None, "ForeignExchangeGainOrLossType": None,
        "GenllLdgrJournalEntryRuleId": None,
        "LastViewedDate": None, "LastReferencedDate": None,
        "Zuora_Id__c": None,
    }
    row.update(overrides)
    return row


TRANSACTION_JOURNAL = [
    _tj_row(
        Id="0lVKa00000TJ00001AAA", Name="S1 - Direct InvoiceLine",
        ActivityDate="2026-08-05T14:30:00.000+0000", TransactionType="InvoiceLine",
        ReferenceTransactionRecordId="a0BKa00000IL0001AAA",
        UsageType="Storage", Debit=1500.00,
        DebitGeneralLedgerAccountId="1KMKa00000GLA001AAA",
    ),
    _tj_row(
        Id="0lVKa00000TJ00002AAA", Name="S2 - InvoiceLineTax indirect",
        ActivityDate="2026-08-06T09:00:00.000+0000", TransactionType="InvoiceLineTax",
        ReferenceTransactionRecordId="a0CKa00000ILT001AAA",
        Credit=45.00,
        CreditGeneralLedgerAccountId="1KMKa00000GLA002AAA",
    ),
    _tj_row(
        Id="0lVKa00000TJ00003AAA", Name="S3 - Payment line-level wins",
        ActivityDate="2026-08-07T11:15:00.000+0000", TransactionType="Payment",
        ReferenceTransactionRecordId="a0FKa00000PAY001AAA",
        Credit=750.00,
        CreditGeneralLedgerAccountId="1KMKa00000GLA003AAA",
    ),
    _tj_row(
        Id="0lVKa00000TJ00004AAA", Name="S4 - CreditMemo line-level wins",
        ActivityDate="2026-08-08T16:45:00.000+0000", TransactionType="CreditMemo",
        ReferenceTransactionRecordId="a0EKa00000CM0001AAA",
        Credit=200.00,
        CreditGeneralLedgerAccountId="1KMKa00000GLA004AAA",
    ),
    _tj_row(
        Id="0lVKa00000TJ00005AAA", Name="S5 - 10040049 GL account override",
        ActivityDate="2026-08-09T08:30:00.000+0000", TransactionType="InvoiceLine",
        ReferenceTransactionRecordId="a0BKa00000IL0001AAA",  # reuses IL1 -- S5 is testing the GL-account override, not a new bu/did path
        UsageType="Subscription", Debit=999.00,
        DebitGeneralLedgerAccountId="1KMKa00000GLA005AAA",
    ),
]


# ---------------------------------------------------------------------------
# invoice_line — full InvoiceLine schema
# ---------------------------------------------------------------------------

def _il_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-01T10:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-01T10:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-01T10:00:00.000+0000",
        "InvoiceId": None, "BillingScheduleId": None, "BillingScheduleGroupId": None,
        "HasMultipleItems": False, "IsUsageBasedInvoiceLine": False,
        "UsageOverageQuantity": None,
        "ReferenceEntityItemId": None, "GroupReferenceEntityItemId": None,
        "LineAmount": None, "Quantity": 1.0, "UnitPrice": None,
        "ChargeAmount": None, "TaxAmount": 0.0, "AdjustmentAmount": 0.0,
        "Balance": 0.0, "NetPaymentsApplied": 0.0, "NetCreditsApplied": 0.0,
        "Status": "Posted", "Description": None,
        "InvoiceLineStartDate": "2026-08-01", "InvoiceLineEndDate": "2026-08-31",
        "ReferenceEntityItemType": None, "ReferenceEntityItemTypeCode": None,
        "Product2Id": None, "Type": "Recurring",
        "ChargeTaxAmount": 0.0, "ChargeAmountWithTax": None,
        "AdjustmentTaxAmount": 0.0, "AdjustmentAmountWithTax": 0.0,
        "TaxTreatmentId": None, "UnitOfMeasureId": None,
        "ShippingAddressId": None, "BillingAddressId": None,
        "TaxProcessingStatus": None, "ConvertedNegAmount": None,
        "LegalEntityId": "0fwKa0000001xaRIAQ", "LegalEntityAccountingPeriodId": None,
        "ChargeConvertedNegAmount": None,
        "UsageProductId": None, "UsageProductBillSchdGrpId": None,
        "ShipFromAddressId": None,
        "Billing_Treatment_Type__c": None,
        "Business_Unit_BU__c": None, "Department_ID_DID__c": None,
        "PO_Number__c": None, "Subscription_Number__c": None,
        "Zuora_Id__c": None,
    }
    row.update(overrides)
    return row


INVOICE_LINE = [
    _il_row(  # IL1 — direct target for TJ1
        Id="a0BKa00000IL0001AAA", Name="00000001-1", InvoiceId="a0AKa00000INV001AAA",
        Product2Id="01tKa00000PROD01AAA", LineAmount=1500.00, UnitPrice=1500.00,
        ChargeAmount=1500.00, Description="Acme Widget Plan - August",
        Business_Unit_BU__c="10902", Department_ID_DID__c="20500",
    ),
    _il_row(  # IL2 — target of ILT1 (tax indirect)
        Id="a0BKa00000IL0002AAA", Name="00000002-1", InvoiceId="a0AKa00000INV002AAA",
        Product2Id="01tKa00000PROD02AAA", LineAmount=450.00, UnitPrice=450.00,
        ChargeAmount=450.00, Description="Support Retainer - August",
        Business_Unit_BU__c="10902", Department_ID_DID__c="20500",
    ),
    _il_row(  # IL3 — correct line-level target for TJ3's Payment
        Id="a0BKa00000IL0003AAA", Name="00000003-1", InvoiceId="a0AKa00000INV003AAA",
        Product2Id="01tKa00000PROD03AAA", LineAmount=750.00, UnitPrice=750.00,
        ChargeAmount=750.00, Description="Professional Services - August",
        Business_Unit_BU__c="10904", Department_ID_DID__c="50500",
    ),
    _il_row(  # IL4 — correct line-level target for TJ4's CreditMemo
        Id="a0BKa00000IL0004AAA", Name="00000004-1", InvoiceId="a0AKa00000INV004AAA",
        Product2Id="01tKa00000PROD04AAA", LineAmount=200.00, UnitPrice=200.00,
        ChargeAmount=200.00, Description="Refund Adjustment - August",
        Business_Unit_BU__c="10905", Department_ID_DID__c="60500",
    ),
    _il_row(  # IL5 — deliberately-wrong "trap": owned by the SAME Invoice
             # that both PAY1's header-level path and CM1's header-level
             # path point at. If line-level priority ever regressed, this
             # bu/did (99999/99999) would show up instead of IL3's/IL4's.
        Id="a0BKa00000IL0005AAA", Name="00000005-1", InvoiceId="a0AKa00000INVTRAPAA",
        Product2Id="01tKa00000PROD05AAA", LineAmount=1.00, UnitPrice=1.00,
        ChargeAmount=1.00, Description="TRAP - should never resolve",
        Business_Unit_BU__c="99999", Department_ID_DID__c="99999",
    ),
]


# ---------------------------------------------------------------------------
# invoice_line_tax — full InvoiceLineTax schema
# ---------------------------------------------------------------------------

def _ilt_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-01T10:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-01T10:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-01T10:00:00.000+0000",
        "InvoiceLineId": None, "TaxAmount": 45.00, "Description": None,
        "StartDate": "2026-08-01", "EndDate": "2026-08-31",
        "ConvertedNegAmount": None,
        "TaxName": "CO State Tax", "TaxCode": "CO-STATE", "TaxRate": 3.0,
        "TaxTransactionNumber": None, "TaxDocumentNumber": None,
        "TaxEffectiveDate": "2026-08-01", "TaxTreatmentId": None,
        "ShippingAddressId": None, "BillingAddressId": None,
        "TaxProcessingStatus": "Processed",
        "LegalEntityId": "0fwKa0000001xaRIAQ", "TaxExemptAmount": 0.0,
        "LegalEntityAccountingPeriodId": None, "ShipFromAddressId": None,
    }
    row.update(overrides)
    return row


INVOICE_LINE_TAX = [
    _ilt_row(  # ILT1 — used by TJ2
        Id="a0CKa00000ILT001AAA", Name="TAX-00001", InvoiceLineId="a0BKa00000IL0002AAA",
        Description="Sales tax on Support Retainer",
    ),
    _ilt_row(Id="a0CKa00000ILT002AAA", Name="TAX-00002", InvoiceLineId="a0BKa00000IL0001AAA",
             Description="Sales tax on Acme Widget Plan"),
    _ilt_row(Id="a0CKa00000ILT003AAA", Name="TAX-00003", InvoiceLineId="a0BKa00000IL0003AAA",
             Description="Sales tax on Professional Services"),
    _ilt_row(Id="a0CKa00000ILT004AAA", Name="TAX-00004", InvoiceLineId="a0BKa00000IL0004AAA",
             Description="Sales tax on Refund Adjustment"),
    _ilt_row(Id="a0CKa00000ILT005AAA", Name="TAX-00005", InvoiceLineId="a0BKa00000IL0005AAA",
             Description="Sales tax on TRAP line"),
]


# ---------------------------------------------------------------------------
# payment_line_invoice_line — full PaymentLineInvoiceLine schema
# ---------------------------------------------------------------------------

def _pli_line_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-07T11:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-07T11:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-07T11:00:00.000+0000",
        "LastViewedDate": None, "LastReferencedDate": None,
        "InvoiceLineId": None, "PaymentId": None,
        "Amount": None, "Type": "Payment", "UnappliedStatus": "Applied",
        "Description": None,
        "AppliedDateTime": "2026-08-07T11:15:00.000+0000",
        "EffectiveDateTime": "2026-08-07T11:15:00.000+0000",
        "UnappliedDateTime": None,
        "RelatedPaymentLineInvcLineId": None,
        "ImpactAmount": None, "AppliedImpactAmount": None,
        "PaymentBalance": 0.0, "InvoiceLineBalance": 0.0,
        "LegalEntityId": "0fwKa0000001xaRIAQ", "LegalEntityAccountingPeriodId": None,
    }
    row.update(overrides)
    return row


PAYMENT_LINE_INVOICE_LINE = [
    _pli_line_row(  # the one that matters — line-level match for TJ3
        Id="a0GKa00000PLL001AAA", Name="PMTLINE-00001", PaymentId="a0FKa00000PAY001AAA",
        InvoiceLineId="a0BKa00000IL0003AAA", Amount=750.00,
        Description="Payment applied to Professional Services line",
    ),
    _pli_line_row(Id="a0GKa00000PLL002AAA", Name="PMTLINE-00002", PaymentId="a0FKa00000PAY002AAA",
                  InvoiceLineId="a0BKa00000IL0001AAA", Amount=100.00),
    _pli_line_row(Id="a0GKa00000PLL003AAA", Name="PMTLINE-00003", PaymentId="a0FKa00000PAY003AAA",
                  InvoiceLineId="a0BKa00000IL0002AAA", Amount=50.00),
    _pli_line_row(Id="a0GKa00000PLL004AAA", Name="PMTLINE-00004", PaymentId="a0FKa00000PAY004AAA",
                  InvoiceLineId="a0BKa00000IL0004AAA", Amount=25.00),
    _pli_line_row(Id="a0GKa00000PLL005AAA", Name="PMTLINE-00005", PaymentId="a0FKa00000PAY005AAA",
                  InvoiceLineId="a0BKa00000IL0005AAA", Amount=1.00),
]


# ---------------------------------------------------------------------------
# payment_line_invoice — full PaymentLineInvoice schema
# ---------------------------------------------------------------------------

def _pli_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-07T11:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-07T11:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-07T11:00:00.000+0000",
        "LastViewedDate": None, "LastReferencedDate": None,
        "InvoiceId": None, "PaymentId": None,
        "Amount": None, "Type": "Payment", "HasBeenUnapplied": "false",
        "Comments": None,
        "Date": "2026-08-07T11:15:00.000+0000", "AppliedDate": "2026-08-07T11:15:00.000+0000",
        "EffectiveDate": "2026-08-07T11:15:00.000+0000", "UnappliedDate": None,
        "AccountId": None, "RelatedPaymentLineInvcLineId": None,
        "ImpactAmount": None, "AppliedImpactAmount": None,
        "PaymentBalance": 0.0, "InvoiceLineBalance": 0.0,
        "LegalEntityId": "0fwKa0000001xaRIAQ", "LegalEntityAccountingPeriodId": None,
    }
    row.update(overrides)
    return row


PAYMENT_LINE_INVOICE = [
    _pli_row(  # header-level "trap" for TJ3 — same PaymentId as the
               # correct line-level match above, but points at IL5's
               # invoice. Line-level must win; if it doesn't, IL5's
               # 99999/99999 bu/did shows up instead of IL3's.
        Id="a0HKa00000PLI001AAA", Name="PMTINV-00001", PaymentId="a0FKa00000PAY001AAA",
        InvoiceId="a0AKa00000INVTRAPAA", Amount=750.00,
    ),
    _pli_row(Id="a0HKa00000PLI002AAA", Name="PMTINV-00002", PaymentId="a0FKa00000PAY002AAA",
             InvoiceId="a0AKa00000INV001AAA", Amount=100.00),
    _pli_row(Id="a0HKa00000PLI003AAA", Name="PMTINV-00003", PaymentId="a0FKa00000PAY003AAA",
             InvoiceId="a0AKa00000INV002AAA", Amount=50.00),
    _pli_row(Id="a0HKa00000PLI004AAA", Name="PMTINV-00004", PaymentId="a0FKa00000PAY004AAA",
             InvoiceId="a0AKa00000INV003AAA", Amount=25.00),
    _pli_row(Id="a0HKa00000PLI005AAA", Name="PMTINV-00005", PaymentId="a0FKa00000PAY005AAA",
             InvoiceId="a0AKa00000INV004AAA", Amount=1.00),
]


# ---------------------------------------------------------------------------
# credit_memo_line — full CreditMemoLine schema
# ---------------------------------------------------------------------------

def _cml_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-08T16:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-08T16:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-08T16:00:00.000+0000",
        "CreditMemoId": None, "ReferenceEntityItemId": None,
        "StartDate": "2026-08-01", "EndDate": "2026-08-31", "TaxEffectiveDate": "2026-08-08",
        "Status": "Posted", "ChargeAmount": None, "TaxAmount": 0.0,
        "AdjustmentAmount": 0.0, "LineAmount": None, "Description": None,
        "ReferenceEntityItemTypeCode": None, "ReferenceEntityItemType": None,
        "Product2Id": None, "TaxTreatmentId": None,
        "ShippingAddressId": None, "BillingAddressId": None,
        "LegalEntityId": "0fwKa0000001xaRIAQ", "LegalEntityAccountingPeriodId": None,
        "Balance": 0.0, "NetCreditsApplied": 0.0, "ShipFromAddressId": None,
    }
    row.update(overrides)
    return row


CREDIT_MEMO_LINE = [
    _cml_row(  # CML1 — used by TJ4's line-level path
        Id="a0DKa00000CML001AAA", Name="00000001-1", CreditMemoId="a0EKa00000CM0001AAA",
        Product2Id="01tKa00000PROD04AAA", ChargeAmount=200.00, LineAmount=200.00,
        Description="Refund Adjustment credit line",
    ),
    _cml_row(Id="a0DKa00000CML002AAA", Name="00000002-1", CreditMemoId="a0EKa00000CM0002AAA",
             Product2Id="01tKa00000PROD01AAA", ChargeAmount=50.00, LineAmount=50.00),
    _cml_row(Id="a0DKa00000CML003AAA", Name="00000003-1", CreditMemoId="a0EKa00000CM0003AAA",
             Product2Id="01tKa00000PROD02AAA", ChargeAmount=25.00, LineAmount=25.00),
    _cml_row(Id="a0DKa00000CML004AAA", Name="00000004-1", CreditMemoId="a0EKa00000CM0004AAA",
             Product2Id="01tKa00000PROD03AAA", ChargeAmount=10.00, LineAmount=10.00),
    _cml_row(Id="a0DKa00000CML005AAA", Name="00000005-1", CreditMemoId="a0EKa00000CM0005AAA",
             Product2Id="01tKa00000PROD05AAA", ChargeAmount=1.00, LineAmount=1.00),
]


# ---------------------------------------------------------------------------
# credit_memo_line_invoice_line — full CreditMemoLineInvoiceLine schema
# ---------------------------------------------------------------------------

def _cmli_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-08T16:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-08T16:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-08T16:00:00.000+0000",
        "InvoiceLineId": None, "CreditMemoLineId": None,
        "Amount": None, "Type": "Credit", "Description": None,
        "AppliedDateTime": "2026-08-08T16:45:00.000+0000",
        "EffectiveDateTime": "2026-08-08T16:45:00.000+0000",
        "UnappliedDateTime": None,
        "RelatedCrMemoLineInvcLineId": None, "UnappliedStatus": "Applied",
    }
    row.update(overrides)
    return row


CREDIT_MEMO_LINE_INVOICE_LINE = [
    _cmli_row(  # the one that matters — line-level match for TJ4
        Id="a0IKa00000CMI001AAA", Name="CMLINV-00001", CreditMemoLineId="a0DKa00000CML001AAA",
        InvoiceLineId="a0BKa00000IL0004AAA", Amount=200.00,
        Description="Credit applied to Refund Adjustment line",
    ),
    _cmli_row(Id="a0IKa00000CMI002AAA", Name="CMLINV-00002", CreditMemoLineId="a0DKa00000CML002AAA",
              InvoiceLineId="a0BKa00000IL0001AAA", Amount=50.00),
    _cmli_row(Id="a0IKa00000CMI003AAA", Name="CMLINV-00003", CreditMemoLineId="a0DKa00000CML003AAA",
              InvoiceLineId="a0BKa00000IL0002AAA", Amount=25.00),
    _cmli_row(Id="a0IKa00000CMI004AAA", Name="CMLINV-00004", CreditMemoLineId="a0DKa00000CML004AAA",
              InvoiceLineId="a0BKa00000IL0003AAA", Amount=10.00),
    _cmli_row(Id="a0IKa00000CMI005AAA", Name="CMLINV-00005", CreditMemoLineId="a0DKa00000CML005AAA",
              InvoiceLineId="a0BKa00000IL0005AAA", Amount=1.00),
]


# ---------------------------------------------------------------------------
# credit_memo_inv_application — full CreditMemoLineInvApplication schema
# ---------------------------------------------------------------------------

def _cmia_row(**overrides):
    row = {
        "Id": None, "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-08-08T16:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-08-08T16:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-08-08T16:00:00.000+0000",
        "InvoiceId": None, "CreditMemoId": None,
        "Amount": None, "Type": "Credit", "Description": None,
        "Date": "2026-08-08T16:45:00.000+0000", "AppliedDate": "2026-08-08T16:45:00.000+0000",
        "EffectiveDate": "2026-08-08T16:45:00.000+0000", "UnappliedDate": None,
        "AssociatedLineId": None,
    }
    row.update(overrides)
    return row


CREDIT_MEMO_INV_APPLICATION = [
    _cmia_row(  # header-level "trap" for TJ4 — same CreditMemoId as the
                # correct line-level match above, but points at IL5's
                # invoice. Line-level must win.
        Id="a0JKa00000CIA001AAA", Name="CMAPP-00001", CreditMemoId="a0EKa00000CM0001AAA",
        InvoiceId="a0AKa00000INVTRAPAA", Amount=200.00,
    ),
    _cmia_row(Id="a0JKa00000CIA002AAA", Name="CMAPP-00002", CreditMemoId="a0EKa00000CM0002AAA",
              InvoiceId="a0AKa00000INV001AAA", Amount=50.00),
    _cmia_row(Id="a0JKa00000CIA003AAA", Name="CMAPP-00003", CreditMemoId="a0EKa00000CM0003AAA",
              InvoiceId="a0AKa00000INV002AAA", Amount=25.00),
    _cmia_row(Id="a0JKa00000CIA004AAA", Name="CMAPP-00004", CreditMemoId="a0EKa00000CM0004AAA",
              InvoiceId="a0AKa00000INV003AAA", Amount=10.00),
    _cmia_row(Id="a0JKa00000CIA005AAA", Name="CMAPP-00005", CreditMemoId="a0EKa00000CM0005AAA",
              InvoiceId="a0AKa00000INV004AAA", Amount=1.00),
]


# ---------------------------------------------------------------------------
# general_ledger_account — full GeneralLedgerAccount schema
# ---------------------------------------------------------------------------

def _gla_row(**overrides):
    row = {
        "Id": None, "OwnerId": "005Ka000005SyJYIA0", "IsDeleted": False, "Name": None,
        "CreatedDate": "2026-02-04T23:00:00.000+0000", "CreatedById": "005Ka000005SyJYIA0",
        "LastModifiedDate": "2026-02-04T23:00:00.000+0000", "LastModifiedById": "005Ka000005SyJYIA0",
        "SystemModstamp": "2026-02-04T23:00:00.000+0000",
        "LastViewedDate": None, "LastReferencedDate": None,
        "AccountingCode": None, "AccountingName": None, "AccountingType": None,
        "FinancialStatement": None, "LegalEntityId": "0fwKa0000001xaRIAQ",
        "Description": None, "Type": None,
        "GL_Accounting_Number__c": None,
    }
    row.update(overrides)
    return row


GENERAL_LEDGER_ACCOUNT = [
    _gla_row(Id="1KMKa00000GLA001AAA", Name="Subscription Revenue", AccountingCode="Sub Rev",
             AccountingName="Subscription Revenue", AccountingType="Revenue", Type="Revenue",
             GL_Accounting_Number__c="20011111"),
    _gla_row(Id="1KMKa00000GLA002AAA", Name="Sales Tax Payable", AccountingCode="Tax Payable",
             AccountingName="Sales Tax Payable", AccountingType="Liability", Type="Liability",
             GL_Accounting_Number__c="20022222"),
    _gla_row(Id="1KMKa00000GLA003AAA", Name="Professional Services Revenue", AccountingCode="PS Rev",
             AccountingName="Professional Services Revenue", AccountingType="Revenue", Type="Revenue",
             GL_Accounting_Number__c="20033333"),
    _gla_row(Id="1KMKa00000GLA004AAA", Name="Refunds and Adjustments", AccountingCode="Refunds",
             AccountingName="Refunds and Adjustments", AccountingType="Contra Revenue", Type="Revenue",
             GL_Accounting_Number__c="20044444"),
    _gla_row(  # the special caveat account — triggers did -> 16605
        Id="1KMKa00000GLA005AAA", Name="Check Cash", AccountingCode="Check",
        AccountingName="Cash", AccountingType="Cash", Type="Asset",
        GL_Accounting_Number__c="10040049",
    ),
]


def generate_all():
    written = []
    written.append(_write("transaction_journal", TRANSACTION_JOURNAL))
    written.append(_write("invoice_line", INVOICE_LINE))
    written.append(_write("invoice_line_tax", INVOICE_LINE_TAX))
    written.append(_write("payment_line_invoice_line", PAYMENT_LINE_INVOICE_LINE))
    written.append(_write("payment_line_invoice", PAYMENT_LINE_INVOICE))
    written.append(_write("credit_memo_line", CREDIT_MEMO_LINE))
    written.append(_write("credit_memo_line_invoice_line", CREDIT_MEMO_LINE_INVOICE_LINE))
    written.append(_write("credit_memo_inv_application", CREDIT_MEMO_INV_APPLICATION))
    written.append(_write("general_ledger_account", GENERAL_LEDGER_ACCOUNT))
    return written


if __name__ == "__main__":
    for path in generate_all():
        with open(path) as f:
            n = sum(1 for _ in f)
        print(f"wrote {path} ({n} rows)")
