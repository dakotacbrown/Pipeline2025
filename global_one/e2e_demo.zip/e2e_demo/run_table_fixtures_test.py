"""
Loads the flat, full-schema fixtures from table_fixtures/*.jsonl (see
generate_table_fixtures.py), lays them out the way S3 actually is
(salesforce/reports/{dataset_id}/data.jsonl), and runs the REAL
gl_source_join.build_source_dataframe() -> salesforce_global_one.build_gl_file()
pipeline against them — proving these standalone table fixtures actually
work to test the GL file, not just that they're well-formed JSON.

Run with: python3 run_table_fixtures_test.py
"""

import os
import sys
from datetime import datetime

DEMO_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(DEMO_DIR)
SCRIPTS_DIR = os.path.join(REPO_ROOT, "src", "salesforce", "resources", "scripts")
STUBS_DIR = os.path.join(REPO_ROOT, "stubs")

sys.path.insert(0, STUBS_DIR)
sys.path.insert(0, REPO_ROOT)
sys.path.insert(0, SCRIPTS_DIR)
sys.path.insert(0, DEMO_DIR)

from fake_s3_client import FakeS3Client  # noqa: E402
import helpers.gl_source_join as gl_source_join  # noqa: E402
import salesforce_global_one as gljb  # noqa: E402

TABLE_FIXTURES_DIR = os.path.join(DEMO_DIR, "table_fixtures")
STAGED_DIR = os.path.join(DEMO_DIR, "table_fixtures_staged")
SOURCE_PREFIX = "salesforce/reports"


def stage_fixtures():
    """Copies each flat table_fixtures/{table}.jsonl into the dataset_id-keyed layout FakeS3Client expects."""
    for table_key, dataset_id in gl_source_join.DATASET_IDS.items():
        src = os.path.join(TABLE_FIXTURES_DIR, f"{table_key}.jsonl")
        if not os.path.exists(src):
            continue  # tables not covered by these fixtures (e.g. account, invoice, credit_memo)
        dst_dir = os.path.join(STAGED_DIR, SOURCE_PREFIX, dataset_id)
        os.makedirs(dst_dir, exist_ok=True)
        with open(src, "rb") as f_in, open(os.path.join(dst_dir, "data.jsonl"), "wb") as f_out:
            f_out.write(f_in.read())


def main():
    import generate_table_fixtures
    import generate_new_table_fixtures
    import generate_product2_fixtures
    generate_table_fixtures.generate_all()
    generate_new_table_fixtures.generate_all()
    generate_product2_fixtures.generate_all()
    stage_fixtures()

    fake_s3 = FakeS3Client(root_dir=STAGED_DIR)

    print("NOTE: refund_line_payment is staged under its PLACEHOLDER dataset_id")
    print("(00000000-0000-0000-0000-000000000000) for this local test only --")
    print("this proves the resolution CODE is correct, not that real prod data")
    print("is available yet. Real production reads will return 0 rows from")
    print("that table until the actual dataset_id registration completes.\n")

    df = gl_source_join.build_source_dataframe(
        fake_s3, bucket="fake-bucket", source_prefix=SOURCE_PREFIX,
        start_date="2026-08-01", end_date="2026-08-20",
    )
    print(f"build_source_dataframe() returned {len(df)} rows\n")
    print(df.to_string())
    print()

    content = gljb.build_gl_file(df, business_unit=None, source="CS1",
                                  creation_dt=datetime(2026, 8, 20, 9, 0, 0))
    print(content)

    print("Checks:")
    print(f"  S1 (IL1, Product2 overrides did 20500->20999): 20999 present: {'20999' in content}")
    print(f"  S12 DebitMemoLine -> bu=10902 present:        {'10902' in content}")
    print(f"  S13 RefundLinePayment direct -> bu=10902:     {'10902' in content}")
    print(f"  S14 Refund via RefundLinePayment hop -> 10902: {'10902' in content}")
    print(f"  IL3 (line-level Payment target)   bu=10904 present: {'10904' in content}")
    print(f"  IL4 (line-level CreditMemo target) bu=10905 present: {'10905' in content}")
    print(f"  IL5 (trap, should NEVER appear)    bu=99999 present: {'99999' in content}  <- must be False")
    print(f"  S5's did override to 16605 present: {'16605' in content}")


if __name__ == "__main__":
    main()
