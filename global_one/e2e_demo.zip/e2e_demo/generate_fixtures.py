"""
Generates realistic JSONL fixture data for every table
gl_source_join.build_source_dataframe() reads, laid out on disk the same
way the real S3 bucket is (salesforce/reports/{dataset_id}/data.jsonl).

Each TransactionJournal row is a distinct, labeled scenario exercising one
specific piece of pipeline logic — see SCENARIOS_README.md for the full
list of what each one proves and what output to expect.

Run this once before run_e2e_test.py (or just run run_e2e_test.py, which
calls this automatically).
"""

import json
import os

from src.salesforce.resources.scripts.helpers.gl_source_join import DATASET_IDS

OUT_DIR = os.path.join(os.path.dirname(__file__), "test_data")
SOURCE_PREFIX = "salesforce/reports"


def _write_jsonl(table_key: str, rows: list):
    """
    Writes rows as JSONL under this table's dataset_id prefix. If rows is
    empty, deliberately writes NOTHING (not even an empty file) — this
    matches how a genuinely empty table looks in real S3 (no objects under
    the prefix at all), which is the code path
    read_jsonl_prefix_from_s3()'s "if not frames: return empty" branch is
    built for. Writing an empty .jsonl file instead would take a different,
    unrealistic code path (pd.read_json on empty content).
    """
    if not rows:
        return None
    dataset_id = DATASET_IDS[table_key]
    dir_path = os.path.join(OUT_DIR, SOURCE_PREFIX, dataset_id)
    os.makedirs(dir_path, exist_ok=True)
    path = os.path.join(dir_path, "data.jsonl")
    with open(path, "w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")
    return path


# ---------------------------------------------------------------------------
# TransactionJournal — 11 scenarios, each labeled by Name so they're easy
# to trace through every downstream output. ActivityDate uses full
# Salesforce-style datetimes (confirmed via Dakota's screenshot) except
# where noted.
# ---------------------------------------------------------------------------

TRANSACTION_JOURNAL = [
    # 1. Plain InvoiceLine transaction, direct resolution path.
    {
        "Name": "S1 - Direct InvoiceLine",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "IL001",
        "TransactionType": "InvoiceLine",
        "ActivityDate": "2026-08-05T14:30:00.000+0000",
        "UsageType": "Storage",
        "Credit": None, "Debit": 1500.00,
        "DebitGeneralLedgerAccountId": "GLA001",
        "CreditGeneralLedgerAccountId": None,
    },
    # 2. Payment, resolved via the header-level fallback (PaymentLineInvoice
    #    -> Invoice -> InvoiceLine) — the path that actually works today.
    {
        "Name": "S2 - Payment header fallback",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "PAY001",
        "TransactionType": "Payment",
        "ActivityDate": "2026-08-06T09:15:00.000+0000",
        "UsageType": None,
        "Credit": 750.00, "Debit": None,
        "DebitGeneralLedgerAccountId": None,
        "CreditGeneralLedgerAccountId": "GLA002",
    },
    # 3. CreditMemo, resolved via the header-level fallback
    #    (CreditMemoInvApplication -> Invoice -> InvoiceLine).
    {
        "Name": "S3 - CreditMemo header fallback",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "CM001",
        "TransactionType": "CreditMemo",
        "ActivityDate": "2026-08-07T11:00:00.000+0000",
        "UsageType": None,
        "Credit": 200.00, "Debit": None,
        "DebitGeneralLedgerAccountId": None,
        "CreditGeneralLedgerAccountId": "GLA003",
    },
    # 4. No matching InvoiceLine anywhere -> bu falls back to the "10901"
    #    default (apply_did_overrides()); did and gl_accounting_number_c
    #    both stay null since nothing overrides them.
    {
        "Name": "S4 - Unresolvable, bu defaults to 10901",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "IL_UNKNOWN",
        "TransactionType": "InvoiceLine",
        "ActivityDate": "2026-08-08T10:00:00.000+0000",
        "UsageType": None,
        "Credit": None, "Debit": 50.00,
        "DebitGeneralLedgerAccountId": None,
        "CreditGeneralLedgerAccountId": None,
    },
    # 5. InvoiceLine.Name contains "Slingshot" -> did overridden to 16637.
    {
        "Name": "S5 - Slingshot product name override",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "IL005",
        "TransactionType": "InvoiceLine",
        "ActivityDate": "2026-08-09T13:45:00.000+0000",
        "UsageType": "Subscription",
        "Credit": None, "Debit": 300.00,
        "DebitGeneralLedgerAccountId": "GLA005",
        "CreditGeneralLedgerAccountId": None,
    },
    # 6. InvoiceLine.Name contains "DataBolt" -> did overridden to 16635.
    {
        "Name": "S6 - DataBolt product name override",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "IL006",
        "TransactionType": "InvoiceLine",
        "ActivityDate": "2026-08-10T08:20:00.000+0000",
        "UsageType": "Subscription",
        "Credit": None, "Debit": 400.00,
        "DebitGeneralLedgerAccountId": "GLA006",
        "CreditGeneralLedgerAccountId": None,
    },
    # 7. gl_accounting_number_c is the special "10040049" account AND the
    #    product name contains "Slingshot" -> the 10040049 override (did ->
    #    16605) must win over the Slingshot override (did -> 16637).
    {
        "Name": "S7 - 10040049 override beats Slingshot override",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "IL007",
        "TransactionType": "InvoiceLine",
        "ActivityDate": "2026-08-11T16:00:00.000+0000",
        "UsageType": "Subscription",
        "Credit": None, "Debit": 999.00,
        "DebitGeneralLedgerAccountId": "GLA_SPECIAL",
        "CreditGeneralLedgerAccountId": None,
    },
    # 8. Dated in July — OUTSIDE the Aug 1-20 test window. Should be
    #    filtered out before any joins even run and never appear in output.
    {
        "Name": "S8 - Outside date window, should be excluded",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "IL008",
        "TransactionType": "InvoiceLine",
        "ActivityDate": "2026-07-15T12:00:00.000+0000",
        "UsageType": None,
        "Credit": None, "Debit": 9999.00,
        "DebitGeneralLedgerAccountId": "GLA001",
        "CreditGeneralLedgerAccountId": None,
    },
    # 9. A second, distinct business unit — proves build_gl_file() groups
    #    into separate Journal Header/Line blocks per BU.
    {
        "Name": "S9 - Second business unit",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "IL009",
        "TransactionType": "InvoiceLine",
        "ActivityDate": "2026-08-12T10:00:00.000+0000",
        "UsageType": "Compute",
        "Credit": None, "Debit": 250.00,
        "DebitGeneralLedgerAccountId": "GLA009",
        "CreditGeneralLedgerAccountId": None,
    },
    # 10. InvoiceLineTax -> InvoiceLine, one hop indirect resolution
    #     (reuses IL001's business unit/department via the tax record).
    {
        "Name": "S10 - InvoiceLineTax indirect resolution",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "ILT001",
        "TransactionType": "InvoiceLineTax",
        "ActivityDate": "2026-08-13T15:30:00.000+0000",
        "UsageType": None,
        "Credit": 45.00, "Debit": None,
        "DebitGeneralLedgerAccountId": None,
        "CreditGeneralLedgerAccountId": "GLA001",
    },
    # 11. Payment with BOTH a line-level match (PaymentLineInvoiceLine) and
    #     a header-level match (PaymentLineInvoice) available — line-level
    #     must win. If header-level won instead, bu/did would come back
    #     99999/99999 (the deliberately-wrong "trap" InvoiceLine below)
    #     instead of the correct 10904/50500.
    {
        "Name": "S11 - Line-level payment wins over header-level",
        "UsageResourceId": None,
        "ReferenceTransactionRecordId": "PAY011",
        "TransactionType": "Payment",
        "ActivityDate": "2026-08-14T09:00:00.000+0000",
        "UsageType": None,
        "Credit": None, "Debit": 600.00,
        "DebitGeneralLedgerAccountId": "GLA011",
        "CreditGeneralLedgerAccountId": None,
    },
]

INVOICE_LINE = [
    {"Id": "IL001", "InvoiceId": "INV001", "Product2Id": "PROD1",
     "Business_Unit_BU__c": "10902", "Department_ID_DID__c": "20500",
     "Name": "Acme Widget Plan"},
    {"Id": "IL002", "InvoiceId": "INV002", "Product2Id": "PROD2",
     "Business_Unit_BU__c": "10902", "Department_ID_DID__c": "20500",
     "Name": "Support Retainer"},
    {"Id": "IL003", "InvoiceId": "INV003", "Product2Id": "PROD3",
     "Business_Unit_BU__c": "10902", "Department_ID_DID__c": "20500",
     "Name": "Refund Adjustment"},
    {"Id": "IL005", "InvoiceId": "INV005", "Product2Id": "PROD5",
     "Business_Unit_BU__c": "10903", "Department_ID_DID__c": "30500",
     "Name": "Slingshot Pro Subscription"},
    {"Id": "IL006", "InvoiceId": "INV006", "Product2Id": "PROD6",
     "Business_Unit_BU__c": "10903", "Department_ID_DID__c": "30500",
     "Name": "DataBolt Starter Plan"},
    {"Id": "IL007", "InvoiceId": "INV007", "Product2Id": "PROD7",
     "Business_Unit_BU__c": "10903", "Department_ID_DID__c": "30500",
     "Name": "Slingshot Enterprise Bundle"},
    {"Id": "IL008", "InvoiceId": "INV008", "Product2Id": "PROD8",
     "Business_Unit_BU__c": "10902", "Department_ID_DID__c": "20500",
     "Name": "Should Never Appear (outside date window)"},
    {"Id": "IL009", "InvoiceId": "INV009", "Product2Id": "PROD9",
     "Business_Unit_BU__c": "20450", "Department_ID_DID__c": "40500",
     "Name": "Analytics Add-on"},
    # Line-level target for scenario 11 — this is the CORRECT match.
    {"Id": "IL011A", "InvoiceId": "INV011", "Product2Id": "PROD11A",
     "Business_Unit_BU__c": "10904", "Department_ID_DID__c": "50500",
     "Name": "LineLevel Plan A"},
    # Header-level "trap" for scenario 11 — shares the same InvoiceId as
    # IL011A but a deliberately wrong bu/did, so if line-level priority
    # ever regresses, this shows up in the output instead and is easy to
    # spot.
    {"Id": "IL011B", "InvoiceId": "INV011", "Product2Id": "PROD11B",
     "Business_Unit_BU__c": "99999", "Department_ID_DID__c": "99999",
     "Name": "HeaderLevel Plan B (should never win)"},
]

INVOICE_LINE_TAX = [
    {"Id": "ILT001", "InvoiceLineId": "IL001"},
]

# Deliberately left with 0 rows — matches production today (per
# gl_source_join.py's own docstring: PaymentLineInvoiceLine/
# CreditMemoLineInvoiceLine currently have 0 rows in real data), EXCEPT
# for scenario 11, which needs exactly one line-level row to prove
# line-level priority.
PAYMENT_LINE_INVOICE_LINE = [
    {"PaymentId": "PAY011", "InvoiceLineId": "IL011A"},
]

PAYMENT_LINE_INVOICE = [
    {"PaymentId": "PAY001", "InvoiceId": "INV002"},
    # Scenario 11's header-level "trap" — present so line-level priority
    # actually gets exercised (both paths resolve to *something*, and the
    # test proves line-level wins).
    {"PaymentId": "PAY011", "InvoiceId": "INV011"},
]

CREDIT_MEMO_LINE = []  # 0 rows — matches production today
CREDIT_MEMO_LINE_INVOICE_LINE = []  # 0 rows — matches production today

CREDIT_MEMO_INV_APPLICATION = [
    {"CreditMemoId": "CM001", "InvoiceId": "INV003"},
]

GENERAL_LEDGER_ACCOUNT = [
    {"Id": "GLA001", "GL_Accounting_Number__c": "20011111"},
    {"Id": "GLA002", "GL_Accounting_Number__c": "20022222"},
    {"Id": "GLA003", "GL_Accounting_Number__c": "20033333"},
    {"Id": "GLA005", "GL_Accounting_Number__c": "20055555"},
    {"Id": "GLA006", "GL_Accounting_Number__c": "20066666"},
    # The special caveat account — triggers the did->16605 override.
    {"Id": "GLA_SPECIAL", "GL_Accounting_Number__c": "10040049"},
    {"Id": "GLA009", "GL_Accounting_Number__c": "20099999"},
    {"Id": "GLA011", "GL_Accounting_Number__c": "20011000"},
]


def generate_all():
    written = []
    written.append(_write_jsonl("transaction_journal", TRANSACTION_JOURNAL))
    written.append(_write_jsonl("invoice_line", INVOICE_LINE))
    written.append(_write_jsonl("invoice_line_tax", INVOICE_LINE_TAX))
    written.append(_write_jsonl("payment_line_invoice_line", PAYMENT_LINE_INVOICE_LINE))
    written.append(_write_jsonl("payment_line_invoice", PAYMENT_LINE_INVOICE))
    written.append(_write_jsonl("credit_memo_line", CREDIT_MEMO_LINE))
    written.append(_write_jsonl("credit_memo_line_invoice_line", CREDIT_MEMO_LINE_INVOICE_LINE))
    written.append(_write_jsonl("credit_memo_inv_application", CREDIT_MEMO_INV_APPLICATION))
    written.append(_write_jsonl("general_ledger_account", GENERAL_LEDGER_ACCOUNT))
    return written


if __name__ == "__main__":
    for path in generate_all():
        print(f"wrote {path}")
